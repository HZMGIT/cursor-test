import { useState, useEffect, useCallback, useRef } from 'react';
import Cookies from 'js-cookie';
import {
  AUTH_TOKEN_KEY,
  getSearchParams,
  SALESSAVVY_FINGERPRINT,
} from '@/lib/utils';
import { webSocketMonitor } from '@/lib/websocket/webSocketMonitor';
import { globalAudioManager } from '@/lib/audio/GlobalAudioManager';
import { globalWebSocketManager } from '@/lib/websocket/GlobalWebSocketManager';
import { createAudioPacket } from '@/lib/audio/audioPacket';
import { toast } from '@/components/hooks/use-toast';

// ==================== 类型定义 ====================
interface AudioWebSocketConfig {
  sampleRate?: number;
  chunkDurationMs?: number;
  onRecordingStart?: () => void;
  onRecordingStop?: () => void;
  onStatusChange?: (status: string) => void;
  onError?: (error: string) => void;
  onMessage?: (message: string) => void;
  onMicrophonePermissionDenied?: (error?: Error) => void;
  onMicrophonePermissionGranted?: () => void;
}

interface AudioWebSocketState {
  isRecording: boolean;
  isConnected: boolean;
  isConnecting: boolean;
  recordingTime: number;
  currentMeetingId?: string;
  microphonePermission?: 'granted' | 'denied' | 'prompt' | 'unknown';
}

interface AudioWebSocketControls {
  startRecording: (meetingId: string) => Promise<void>;
  stopRecording: () => void;
  connectWebSocket: (meetingId: string) => void;
  disconnectWebSocket: () => void;
  sendAudioData: (
    audioData: Float32Array,
    type: 'microphone' | 'screenShare' | 'mixed'
  ) => void;
  cleanup: () => void;
  checkMicrophonePermission?: () => Promise<boolean>;
}

interface UseAudioWebSocketReturn
  extends AudioWebSocketState, AudioWebSocketControls {
  formattedTime: string;
  sampleRate: number;
  chunkDurationMs: number;
  samplesPerChunk: number;
}

// ==================== React Hook ====================
export function useAudioWebSocket(
  config: AudioWebSocketConfig = {}
): UseAudioWebSocketReturn {
  const {
    sampleRate = 16000,
    chunkDurationMs = 200,
    onRecordingStart,
    onRecordingStop,
    onStatusChange,
    onError,
    onMessage,
    onMicrophonePermissionDenied,
    onMicrophonePermissionGranted,
  } = config;

  // 使用ref存储回调函数，避免无限循环
  const callbacksRef = useRef({
    onRecordingStart,
    onRecordingStop,
    onStatusChange,
    onError,
    onMessage,
  });

  // 更新回调ref
  useEffect(() => {
    callbacksRef.current = {
      onRecordingStart,
      onRecordingStop,
      onStatusChange,
      onError,
      onMessage,
    };
  }, [onRecordingStart, onRecordingStop, onStatusChange, onError, onMessage]);

  // 本地状态 - 完全独立于全局状态
  const [isRecording, setIsRecording] = useState(() =>
    globalAudioManager.isRecordingActive()
  );
  const [isConnected, setIsConnected] = useState(() =>
    globalWebSocketManager.isConnected()
  );
  const [isConnecting, setIsConnecting] = useState(() =>
    globalWebSocketManager.isConnecting()
  );
  const [recordingTime, setRecordingTime] = useState(0);
  const [currentMeetingId, setCurrentMeetingId] = useState<string>();
  // 添加权限状态
  const [microphonePermission, setMicrophonePermission] = useState<
    'granted' | 'denied' | 'prompt' | 'unknown'
  >('unknown');
  // 在组件中添加 ref
  const isStartingRef = useRef(false);

  // Ref存储临时状态
  const meetingIdRef = useRef<string>('');
  const isMountedRef = useRef(true);
  const lastRecordingStateRef = useRef(isRecording);

  // 计算参数
  const SAMPLES_PER_CHUNK = Math.floor((sampleRate * chunkDurationMs) / 1000);

  // 生成WebSocket URL
  const getWebSocketUrl = useCallback(
    (meetingId: string) => {
      const token = Cookies.get(AUTH_TOKEN_KEY);
      const deviceId = Cookies.get(SALESSAVVY_FINGERPRINT);

      const urlParams = {
        token,
        deviceId,
        meetingId,
        sample: sampleRate,
        channels: 1,
        byteOrder: 'le',
      };

      // return `ws://salessavvy-server-dev.pa-lt.zkj.local/server/ws/audio/browser?${getSearchParams(urlParams)}`;
      console.log('window.__SALESSAVVY_CONF__', window.__SALESSAVVY_CONF__);
      return `${window.__SALESSAVVY_CONF__?.WS_SERVER_HOST}/ws/audio/browser?${getSearchParams(urlParams)}`;
    },
    [sampleRate]
  );

  // 发送音频数据
  const sendAudioData = useCallback(
    (audioData: Float32Array, type: 'microphone' | 'screenShare' | 'mixed') => {
      if (!globalWebSocketManager.isConnected()) {
        return;
      }

      try {
        let headerType = 0;
        switch (type) {
          case 'microphone':
            headerType = 1;
            break;
          case 'screenShare':
            headerType = 2;
            break;
          case 'mixed':
            headerType = 0;
            break;
        }

        const audioPacket = createAudioPacket(audioData, headerType);
        const sent = globalWebSocketManager.send(audioPacket.buffer);

        if (sent) {
          // 每次成功发送数据时更新活跃时间
          webSocketMonitor.updateActiveTime(currentMeetingId);
        }
      } catch (error) {
        console.error(`Failed to send ${type} audio data:`, error);
      }
    },
    [currentMeetingId]
  );

  // 连接WebSocket
  const connectWebSocket = useCallback(
    (meetingId: string) => {
      if (!meetingId) return;

      // 如果已经连接到相同的 meetingId，直接返回
      if (
        globalWebSocketManager.isConnected() &&
        meetingIdRef.current === meetingId
      ) {
        console.log('Already connected to this meeting');
        return;
      }

      meetingIdRef.current = meetingId;
      setCurrentMeetingId(meetingId);

      const url = getWebSocketUrl(meetingId);

      // 如果已有连接但不是同一个 meetingId，先断开
      if (
        globalWebSocketManager.isConnected() &&
        meetingIdRef.current !== meetingId
      ) {
        globalWebSocketManager.disconnect();
      }

      // 只在新连接时增加引用计数
      if (!globalWebSocketManager.isConnected()) {
        globalWebSocketManager.addRef();
        globalWebSocketManager.connect(url);
        setIsConnecting(true);
      }
    },
    [getWebSocketUrl]
  );

  // WebSocket事件处理
  useEffect(() => {
    const handleOpen = (event: Event) => {
      if (!isMountedRef.current) return;

      setIsConnected(true);
      setIsConnecting(false);
      callbacksRef.current.onStatusChange?.('connected');
    };

    const handleClose = (event: CloseEvent) => {
      if (!isMountedRef.current) return;

      setIsConnected(false);
      setIsConnecting(false);
      callbacksRef.current.onStatusChange?.('disconnected');
    };

    const handleMessage = (event: MessageEvent) => {
      if (!isMountedRef.current) return;
      callbacksRef.current.onMessage?.(event.data);
    };

    const handleError = (event: Event) => {
      if (!isMountedRef.current) return;
      callbacksRef.current.onError?.('WebSocket connection error');
    };

    // 添加事件监听器
    globalWebSocketManager.addOpenListener(handleOpen);
    globalWebSocketManager.addCloseListener(handleClose);
    globalWebSocketManager.addMessageListener(handleMessage);
    globalWebSocketManager.addErrorListener(handleError);

    // 订阅连接状态变化
    const unsubscribe = globalWebSocketManager.subscribeToConnection(
      (connected) => {
        if (!isMountedRef.current) return;
        setIsConnected(connected);
      }
    );

    return () => {
      globalWebSocketManager.removeOpenListener(handleOpen);
      globalWebSocketManager.removeCloseListener(handleClose);
      globalWebSocketManager.removeMessageListener(handleMessage);
      globalWebSocketManager.removeErrorListener(handleError);
      unsubscribe();
    };
  }, []);

  // 订阅音频管理器状态
  useEffect(() => {
    // 设置音频参数和发送回调
    globalAudioManager.setAudioParams(sampleRate, chunkDurationMs);
    globalAudioManager.setSendAudioDataCallback(sendAudioData);

    // 订阅音频状态变化
    const unsubscribe = globalAudioManager.subscribe((state) => {
      if (!isMountedRef.current) return;

      setIsRecording(state.isRecording);
      setRecordingTime(state.recordingTime);

      // 只在状态变化时调用回调
      if (state.isRecording && !lastRecordingStateRef.current) {
        lastRecordingStateRef.current = true;
        callbacksRef.current.onRecordingStart?.();
        callbacksRef.current.onStatusChange?.('recording');
      } else if (!state.isRecording && lastRecordingStateRef.current) {
        lastRecordingStateRef.current = false;
        callbacksRef.current.onRecordingStop?.();
        callbacksRef.current.onStatusChange?.('stopped');
      }
    });

    return () => {
      unsubscribe();
    };
  }, [sampleRate, chunkDurationMs, sendAudioData]);

  // 检查麦克风权限状态
  const checkMicrophonePermission = useCallback(async (): Promise<boolean> => {
    try {
      // 使用 Permissions API 检查权限状态
      if (navigator.permissions && navigator.permissions.query) {
        const permissionStatus = await navigator.permissions.query({
          name: 'microphone' as PermissionName,
        });

        setMicrophonePermission(permissionStatus.state as any);

        // 监听权限变化
        permissionStatus.onchange = () => {
          setMicrophonePermission(permissionStatus.state as any);
        };

        return permissionStatus.state === 'granted';
      }

      // 回退方案：直接尝试获取权限
      return new Promise((resolve) => {
        navigator.mediaDevices
          .getUserMedia({ audio: true })
          .then((stream) => {
            stream.getTracks().forEach((track) => track.stop());
            setMicrophonePermission('granted');
            resolve(true);
          })
          .catch((error) => {
            console.error('Microphone permission check failed:', error);
            if (
              error.name === 'NotAllowedError' ||
              error.name === 'PermissionDeniedError'
            ) {
              setMicrophonePermission('denied');
            } else {
              setMicrophonePermission('prompt');
            }
            resolve(false);
          });
      });
    } catch (error) {
      console.error('Failed to check microphone permission:', error);
      return false;
    }
  }, []);

  // 开始录制
  const startRecording = useCallback(
    async (meetingId: string) => {
      if (!meetingId) return;

      // 定义错误处理器
      const handlePermissionError = (error?: Error) => {
        console.error('麦克风权限错误:', error);
        setMicrophonePermission('denied');
        onMicrophonePermissionDenied?.(error);
      };

      // 1. 检查是否已经在录音
      if (globalAudioManager.isRecordingActive()) {
        console.log('Recording is already active');
        return;
      }

      // 2. 使用标记避免重复执行
      if (isStartingRef.current) {
        console.log('Recording is already starting');
        return;
      }

      isStartingRef.current = true;

      try {
        // 先检查权限状态
        const hasPermission = await checkMicrophonePermission();

        if (!hasPermission && microphonePermission === 'denied') {
          handlePermissionError(new Error('麦克风权限已被拒绝'));
          return;
        }

        // 添加调试日志
        console.log('Checking for connections in other tabs...');
        const stats = webSocketMonitor.getStats();
        console.log('Current connection stats:', stats);

        // 检查跨标签页连接 - 使用更精确的判断
        const hasConnectionInOtherTab =
          webSocketMonitor.hasActiveConnection() &&
          !webSocketMonitor.hasConnectionInThisTab();

        console.log('Connection check result:', {
          hasActiveConnection: webSocketMonitor.hasActiveConnection(),
          hasConnectionInThisTab: webSocketMonitor.hasConnectionInThisTab(),
          hasConnectionInOtherTab,
        });

        if (hasConnectionInOtherTab) {
          toast({
            description: '其他标签页正在录音',
            variant: 'info',
          });
          return;
        }

        // 连接WebSocket
        connectWebSocket(meetingId);

        // 等待连接
        await new Promise<void>((resolve) => {
          if (globalWebSocketManager.isConnected()) {
            resolve();
            return;
          }

          let attempts = 0;
          const maxAttempts = 50;
          const interval = setInterval(() => {
            attempts++;
            if (globalWebSocketManager.isConnected()) {
              clearInterval(interval);
              resolve();
            } else if (attempts >= maxAttempts) {
              clearInterval(interval);
              console.warn('WebSocket connection timeout');
              resolve();
            }
          }, 100);
        });

        // 开始录音，传递错误处理器
        const success = await globalAudioManager.startRecording(
          handlePermissionError
        );

        if (success) {
          // 在连接建立且录音开始后标记连接
          webSocketMonitor.connect(meetingId);
          webSocketMonitor.updateActiveTime(meetingId);

          // 启动定期更新活跃时间的定时器
          const updateInterval = setInterval(() => {
            if (globalWebSocketManager.isConnected()) {
              webSocketMonitor.updateActiveTime(meetingId);
            }
          }, 2000); // 每2秒更新一次

          // 存储定时器以便清理
          const intervalId = updateInterval as unknown as number;

          setMicrophonePermission('granted');
          onMicrophonePermissionGranted?.();
        }
        // 如果 success 为 false，错误已经在 handlePermissionError 中处理了
      } catch (error: any) {
        console.error('开始录音失败:', error);

        // 处理其他错误
        if (
          error.name === 'NotAllowedError' ||
          error.name === 'PermissionDeniedError'
        ) {
          handlePermissionError(error);
        } else {
          callbacksRef.current.onError?.('开始录音失败: ' + error.message);
        }
      } finally {
        isStartingRef.current = false;
      }
    },
    [
      checkMicrophonePermission,
      connectWebSocket,
      microphonePermission,
      onMicrophonePermissionDenied,
      onMicrophonePermissionGranted,
    ]
  );

  // 组件挂载时检查权限
  useEffect(() => {
    checkMicrophonePermission();
  }, [checkMicrophonePermission]);

  // 在 useAudioWebSocket 中，定期更新活跃时间
  useEffect(() => {
    if (isConnected) {
      // 每10秒更新一次活跃时间
      const updateInterval = setInterval(() => {
        webSocketMonitor.updateActiveTime();
      }, 10000);

      return () => {
        clearInterval(updateInterval);
      };
    }
  }, [isConnected]);

  // 停止录制
  const stopRecording = useCallback(() => {
    globalAudioManager.stopRecording();
    globalWebSocketManager.removeRef();
    // 标记当前标签页已断开
    webSocketMonitor.disconnect();
  }, []);

  // 断开WebSocket
  const disconnectWebSocket = useCallback(() => {
    globalWebSocketManager.removeRef();
  }, []);

  // 清理
  const cleanup = useCallback(() => {
    stopRecording();
    disconnectWebSocket();
  }, [stopRecording, disconnectWebSocket]);

  // 格式化时间
  const getFormattedTime = useCallback((seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  }, []);

  // 组件挂载/卸载
  useEffect(() => {
    isMountedRef.current = true;

    return () => {
      isMountedRef.current = false;
    };
  }, []);

  return {
    // 状态
    isRecording,
    isConnected,
    isConnecting,
    recordingTime,
    currentMeetingId,

    // 计算属性
    formattedTime: getFormattedTime(recordingTime),

    // 控制方法
    startRecording,
    stopRecording,
    connectWebSocket,
    disconnectWebSocket,
    sendAudioData,
    cleanup,
    microphonePermission,
    checkMicrophonePermission,

    // 音频参数
    sampleRate,
    chunkDurationMs,
    samplesPerChunk: SAMPLES_PER_CHUNK,
  };
}

// 导出全局检查函数
export const hasActiveAudioRecording = () =>
  globalAudioManager.isRecordingActive();
export const hasActiveWebSocketConnection = () =>
  globalWebSocketManager.isConnected();
export const getGlobalAudioManager = () => globalAudioManager;
export const getGlobalWebSocketManager = () => globalWebSocketManager;
