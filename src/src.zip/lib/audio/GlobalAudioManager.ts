class GlobalAudioManager {
  private static instance: GlobalAudioManager;
  private isRecording = false;
  private recordingStartTime = 0;
  private recordingTimer: NodeJS.Timeout | null = null;

  // 音频资源
  private microphoneStream: MediaStream | null = null;
  private screenShareStream: MediaStream | null = null;
  private audioContext: AudioContext | null = null;
  private microphoneSource: MediaStreamAudioSourceNode | null = null;
  private screenShareSource: MediaStreamAudioSourceNode | null = null;
  private microphoneProcessor: ScriptProcessorNode | null = null;
  private screenShareProcessor: ScriptProcessorNode | null = null;

  // 音频缓冲区
  private microphoneBuffer: Float32Array = new Float32Array(0);
  private screenShareBuffer: Float32Array = new Float32Array(0);

  // 音频参数
  private sampleRate = 16000;
  private chunkDurationMs = 200;
  private samplesPerChunk = 0;
  private hasScreenShareAudio = false;

  // 回调函数
  private sendAudioDataCallback:
    | ((
        audioData: Float32Array,
        type: 'microphone' | 'screenShare' | 'mixed'
      ) => void)
    | null = null;

  // 状态订阅者
  private subscribers: Set<(state: any) => void> = new Set();
  private lastNotifiedState: any = null;

  private constructor() {
    this.calculateSamplesPerChunk();
  }

  static getInstance(): GlobalAudioManager {
    if (!GlobalAudioManager.instance) {
      GlobalAudioManager.instance = new GlobalAudioManager();
    }
    return GlobalAudioManager.instance;
  }

  private calculateSamplesPerChunk(): void {
    this.samplesPerChunk = Math.floor(
      (this.sampleRate * this.chunkDurationMs) / 1000
    );
  }

  setAudioParams(sampleRate: number, chunkDurationMs: number): void {
    this.sampleRate = sampleRate;
    this.chunkDurationMs = chunkDurationMs;
    this.calculateSamplesPerChunk();
  }

  setSendAudioDataCallback(
    callback: (
      audioData: Float32Array,
      type: 'microphone' | 'screenShare' | 'mixed'
    ) => void
  ): void {
    this.sendAudioDataCallback = callback;
  }

  subscribe(callback: (state: any) => void): () => void {
    this.subscribers.add(callback);

    // 立即发送当前状态
    setTimeout(() => {
      callback(this.getState());
    }, 0);

    return () => {
      this.subscribers.delete(callback);
    };
  }

  private notifySubscribers(): void {
    const currentState = this.getState();

    // 检查状态是否真的改变了
    const shouldNotify =
      !this.lastNotifiedState ||
      JSON.stringify(currentState) !== JSON.stringify(this.lastNotifiedState);

    if (shouldNotify) {
      this.lastNotifiedState = currentState;

      // 异步通知所有订阅者
      setTimeout(() => {
        this.subscribers.forEach((callback) => {
          try {
            callback(currentState);
          } catch (error) {
            console.error('Error in subscriber callback:', error);
          }
        });
      }, 0);
    }
  }

  private getState() {
    return {
      isRecording: this.isRecording,
      recordingTime: this.isRecording
        ? Math.floor((Date.now() - this.recordingStartTime) / 1000)
        : 0,
    };
  }

  async startRecording(
    onMicrophonePermissionDenied: () => void
  ): Promise<boolean> {
    if (this.isRecording) {
      console.warn('Recording is already in progress');
      return false;
    }

    try {
      console.log('Starting global recording...');

      // 1. 获取麦克风权限
      try {
        this.microphoneStream = await navigator.mediaDevices.getUserMedia({
          audio: {
            echoCancellation: false,
            noiseSuppression: false,
            autoGainControl: false,
            sampleRate: this.sampleRate,
            channelCount: 1,
          },
        });
        console.log('Microphone permission granted');
      } catch (error) {
        // TODO 手动拒绝权限
        console.error('Microphone permission denied:', error);
        onMicrophonePermissionDenied?.(); // 传递错误对象
        return false;
      }

      // 2. 尝试获取屏幕共享权限
      try {
        this.screenShareStream = await navigator.mediaDevices.getDisplayMedia({
          video: true,
          audio: true,
        });

        this.hasScreenShareAudio =
          this.screenShareStream.getAudioTracks().length > 0;
        console.log(
          'Screen share permission granted, has audio:',
          this.hasScreenShareAudio
        );
      } catch (error) {
        console.warn('Screen share permission denied:', error);
        this.hasScreenShareAudio = false;
      }

      // 3. 创建音频处理器
      if (!this.createAudioProcessors()) {
        this.cleanupAudioResources();
        return false;
      }

      // 4. 开始录制
      this.isRecording = true;
      this.recordingStartTime = Date.now();

      // 启动录制计时器
      this.recordingTimer = setInterval(() => {
        this.notifySubscribers();
      }, 1000);

      console.log('Global recording started successfully');
      return true;
    } catch (error) {
      console.error('Failed to start global recording:', error);
      this.cleanupAudioResources();
      return false;
    }
  }

  private createAudioProcessors(): boolean {
    try {
      if (!this.audioContext) {
        this.audioContext = new (
          window.AudioContext || (window as any).webkitAudioContext
        )({
          sampleRate: this.sampleRate,
        });
      }

      // 麦克风音频处理器
      if (this.microphoneStream) {
        this.microphoneSource = this.audioContext.createMediaStreamSource(
          this.microphoneStream
        );
        this.microphoneProcessor = this.audioContext.createScriptProcessor(
          2048,
          1,
          1
        );

        this.microphoneProcessor.onaudioprocess = (event) => {
          this.processMicrophoneAudio(event);
        };

        this.microphoneSource.connect(this.microphoneProcessor);
        this.microphoneProcessor.connect(this.audioContext.destination);
      }

      // 屏幕共享音频处理器
      if (this.screenShareStream && this.hasScreenShareAudio) {
        this.screenShareSource = this.audioContext.createMediaStreamSource(
          this.screenShareStream
        );
        this.screenShareProcessor = this.audioContext.createScriptProcessor(
          2048,
          1,
          1
        );

        this.screenShareProcessor.onaudioprocess = (event) => {
          this.processScreenShareAudio(event);
        };

        this.screenShareSource.connect(this.screenShareProcessor);
        this.screenShareProcessor.connect(this.audioContext.destination);
      }

      return true;
    } catch (error) {
      console.error('Failed to create audio processors:', error);
      return false;
    }
  }

  private processMicrophoneAudio(event: AudioProcessingEvent): void {
    if (!this.isRecording || !this.sendAudioDataCallback) return;

    const inputData = event.inputBuffer.getChannelData(0);
    const newBuffer = new Float32Array(
      this.microphoneBuffer.length + inputData.length
    );
    newBuffer.set(this.microphoneBuffer);
    newBuffer.set(inputData, this.microphoneBuffer.length);
    this.microphoneBuffer = newBuffer;

    this.processAndSendAudio();
  }

  private processScreenShareAudio(event: AudioProcessingEvent): void {
    if (
      !this.isRecording ||
      !this.sendAudioDataCallback ||
      !this.hasScreenShareAudio
    )
      return;

    const inputData = event.inputBuffer.getChannelData(0);
    const newBuffer = new Float32Array(
      this.screenShareBuffer.length + inputData.length
    );
    newBuffer.set(this.screenShareBuffer);
    newBuffer.set(inputData, this.screenShareBuffer.length);
    this.screenShareBuffer = newBuffer;

    this.processAndSendAudio();
  }

  private processAndSendAudio(): void {
    if (!this.isRecording || !this.sendAudioDataCallback) return;

    if (this.microphoneBuffer.length >= this.samplesPerChunk) {
      const micChunk = this.microphoneBuffer.slice(0, this.samplesPerChunk);
      this.microphoneBuffer = this.microphoneBuffer.slice(this.samplesPerChunk);

      // 发送麦克风流
      this.sendAudioDataCallback(micChunk, 'microphone');

      if (this.hasScreenShareAudio) {
        if (this.screenShareBuffer.length >= this.samplesPerChunk) {
          const screenChunk = this.screenShareBuffer.slice(
            0,
            this.samplesPerChunk
          );
          this.screenShareBuffer = this.screenShareBuffer.slice(
            this.samplesPerChunk
          );

          // 发送屏幕共享流
          this.sendAudioDataCallback(screenChunk, 'screenShare');

          // 创建并发送混合音频
          const mixedChunk = new Float32Array(this.samplesPerChunk);
          for (let i = 0; i < this.samplesPerChunk; i++) {
            mixedChunk[i] = (micChunk[i] + screenChunk[i]) / 2;
            mixedChunk[i] = Math.max(-1, Math.min(1, mixedChunk[i]));
          }
          this.sendAudioDataCallback(mixedChunk, 'mixed');
        } else {
          this.sendAudioDataCallback(micChunk, 'mixed');
        }
      } else {
        this.sendAudioDataCallback(micChunk, 'mixed');
      }
    }
  }

  stopRecording(): void {
    if (!this.isRecording) return;

    console.log('Stopping global recording...');
    this.isRecording = false;

    if (this.recordingTimer) {
      clearInterval(this.recordingTimer);
      this.recordingTimer = null;
    }

    this.cleanupAudioResources();
    this.notifySubscribers();

    console.log('Global recording stopped');
  }

  private cleanupAudioResources(): void {
    [this.microphoneProcessor, this.screenShareProcessor].forEach(
      (processor) => {
        if (processor) {
          processor.disconnect();
          processor.onaudioprocess = null;
        }
      }
    );

    [this.microphoneSource, this.screenShareSource].forEach((source) => {
      if (source) {
        source.disconnect();
      }
    });

    [this.microphoneStream, this.screenShareStream].forEach((stream) => {
      if (stream) {
        stream.getTracks().forEach((track) => {
          track.stop();
          track.enabled = false;
        });
      }
    });

    if (this.audioContext && this.audioContext.state !== 'closed') {
      this.audioContext.close().catch(console.error);
    }

    this.audioContext = null;
    this.microphoneSource = null;
    this.screenShareSource = null;
    this.microphoneProcessor = null;
    this.screenShareProcessor = null;
    this.microphoneStream = null;
    this.screenShareStream = null;
    this.hasScreenShareAudio = false;
    this.microphoneBuffer = new Float32Array(0);
    this.screenShareBuffer = new Float32Array(0);
  }

  isRecordingActive(): boolean {
    return this.isRecording;
  }

  cleanup(): void {
    this.stopRecording();
    this.sendAudioDataCallback = null;
    this.subscribers.clear();
  }
}

export const globalAudioManager = GlobalAudioManager.getInstance();
