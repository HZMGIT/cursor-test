class GlobalWebSocketManager {
  private static instance: GlobalWebSocketManager;
  private webSocket: WebSocket | null = null;
  private connectionUrl: string | null = null;
  private refCount = 0;
  private isManualDisconnect = false;

  // 事件监听器
  private openListeners: ((event: Event) => void)[] = [];
  private closeListeners: ((event: CloseEvent) => void)[] = [];
  private messageListeners: ((event: MessageEvent) => void)[] = [];
  private errorListeners: ((event: Event) => void)[] = [];

  // 连接状态订阅者
  private connectionSubscribers: Set<(connected: boolean) => void> = new Set();

  private constructor() {}

  static getInstance(): GlobalWebSocketManager {
    if (!GlobalWebSocketManager.instance) {
      GlobalWebSocketManager.instance = new GlobalWebSocketManager();
    }
    return GlobalWebSocketManager.instance;
  }

  connect(url: string): WebSocket {
    // 检查是否是同一个 URL 且已经连接
    if (
      this.webSocket &&
      this.connectionUrl === url &&
      this.webSocket.readyState === WebSocket.OPEN
    ) {
      console.log('Reusing existing WebSocket connection');
      return this.webSocket;
    }

    // 如果正在连接中，直接返回现有的 WebSocket
    if (this.webSocket && this.webSocket.readyState === WebSocket.CONNECTING) {
      console.log('WebSocket is already connecting');
      return this.webSocket;
    }

    // 如果已有连接，先关闭
    if (this.webSocket) {
      this.disconnect();
    }

    console.log('Connecting to WebSocket:', url);
    this.connectionUrl = url;
    this.isManualDisconnect = false;

    try {
      this.webSocket = new WebSocket(url);

      this.webSocket.onopen = (event) => {
        console.log('WebSocket connected');
        this.openListeners.forEach((listener) => listener(event));
        this.notifyConnectionChange(true);
      };

      this.webSocket.onclose = (event) => {
        console.log('WebSocket closed:', event.code, event.reason);
        this.closeListeners.forEach((listener) => listener(event));
        this.notifyConnectionChange(false);

        if (!this.isManualDisconnect) {
          setTimeout(() => {
            if (this.connectionUrl && this.refCount > 0) {
              this.connect(this.connectionUrl);
            }
          }, 1000);
        }
      };

      this.webSocket.onmessage = (event) => {
        this.messageListeners.forEach((listener) => listener(event));
      };

      this.webSocket.onerror = (event) => {
        console.error('WebSocket error:', event);
        this.errorListeners.forEach((listener) => listener(event));
      };

      return this.webSocket;
    } catch (error) {
      console.error('Failed to create WebSocket:', error);
      throw error;
    }
  }

  addRef(): void {
    this.refCount++;
  }

  removeRef(): void {
    if (this.refCount > 0) {
      this.refCount--;

      if (this.refCount === 0) {
        this.disconnect();
      }
    }
  }

  send(data: string | ArrayBuffer | Blob | ArrayBufferView | any): boolean {
    if (this.webSocket && this.webSocket.readyState === WebSocket.OPEN) {
      try {
        this.webSocket.send(data);
        return true;
      } catch (error) {
        console.error('Failed to send data:', error);
        return false;
      }
    }
    return false;
  }

  disconnect(): void {
    this.isManualDisconnect = true;

    if (this.webSocket) {
      try {
        this.webSocket.close();
      } catch (error) {
        console.error('Error closing WebSocket:', error);
      }
    }

    this.webSocket = null;
    this.connectionUrl = null;
  }

  isConnected(): boolean {
    return (
      this.webSocket !== null && this.webSocket.readyState === WebSocket.OPEN
    );
  }

  isConnecting(): boolean {
    return (
      this.webSocket !== null &&
      this.webSocket.readyState === WebSocket.CONNECTING
    );
  }

  addOpenListener(listener: (event: Event) => void): void {
    this.openListeners.push(listener);
  }

  removeOpenListener(listener: (event: Event) => void): void {
    const index = this.openListeners.indexOf(listener);
    if (index > -1) {
      this.openListeners.splice(index, 1);
    }
  }

  addCloseListener(listener: (event: CloseEvent) => void): void {
    this.closeListeners.push(listener);
  }

  removeCloseListener(listener: (event: CloseEvent) => void): void {
    const index = this.closeListeners.indexOf(listener);
    if (index > -1) {
      this.closeListeners.splice(index, 1);
    }
  }

  addMessageListener(listener: (event: MessageEvent) => void): void {
    this.messageListeners.push(listener);
  }

  removeMessageListener(listener: (event: MessageEvent) => void): void {
    const index = this.messageListeners.indexOf(listener);
    if (index > -1) {
      this.messageListeners.splice(index, 1);
    }
  }

  addErrorListener(listener: (event: Event) => void): void {
    this.errorListeners.push(listener);
  }

  removeErrorListener(listener: (event: Event) => void): void {
    const index = this.errorListeners.indexOf(listener);
    if (index > -1) {
      this.errorListeners.splice(index, 1);
    }
  }

  subscribeToConnection(callback: (connected: boolean) => void): () => void {
    this.connectionSubscribers.add(callback);

    setTimeout(() => {
      callback(this.isConnected());
    }, 0);

    return () => {
      this.connectionSubscribers.delete(callback);
    };
  }

  private notifyConnectionChange(connected: boolean): void {
    setTimeout(() => {
      this.connectionSubscribers.forEach((callback) => {
        try {
          callback(connected);
        } catch (error) {
          console.error('Error in connection subscriber:', error);
        }
      });
    }, 0);
  }

  cleanup(): void {
    this.disconnect();
    this.openListeners = [];
    this.closeListeners = [];
    this.messageListeners = [];
    this.errorListeners = [];
    this.connectionSubscribers.clear();
    this.refCount = 0;
  }
}

export const globalWebSocketManager = GlobalWebSocketManager.getInstance();
